package com.itbankus.fetchdatausingretrofit.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.itbankus.fetchdatausingretrofit.R;
import com.itbankus.fetchdatausingretrofit.adapter.CurrencyAdapter;
import com.itbankus.fetchdatausingretrofit.presenter.MainPresenter;
import com.itbankus.fetchdatausingretrofit.presenter.MainPresenterImpl;

import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements MainPresenter.MainView {

    @BindView(R.id.recycler)
    RecyclerView recyclerView;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    private String TAG = MainActivity.class.getSimpleName();
    private MainPresenterImpl presenter;
    private CurrencyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //bind ui using butterknife
        // we don't need to do findviewbyid
        ButterKnife.bind(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //initialize presenter
        presenter = new MainPresenterImpl(this, this);
        presenter.getLatestCurrencyData();
    }

    @Override
    public void showLoading() {
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void showRate(String info, String description, Map<String, String> rates) {
        adapter = new CurrencyAdapter(this, rates);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(adapter);
    }
}
