package com.itbankus.fetchdatausingretrofit.api;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiManager {
    public static String BASE_URL = "https://forex.cbm.gov.mm";

    public static Retrofit getRetrofitInstance() {
        OkHttpClient.Builder okHttpClient = new OkHttpClient.Builder();
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create());
        return builder.client(okHttpClient.build())
                .build();

    }
}
