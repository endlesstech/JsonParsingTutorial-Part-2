package com.itbankus.fetchdatausingretrofit.presenter;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.itbankus.fetchdatausingretrofit.api.ApiManager;
import com.itbankus.fetchdatausingretrofit.api.ApiServices;
import com.itbankus.fetchdatausingretrofit.model.CurrencyResponse;
import com.itbankus.fetchdatausingretrofit.view.MainActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainPresenterImpl implements MainPresenter.MainAllActions {
    String TAG = MainPresenterImpl.class.getSimpleName();
    Context context;
    MainPresenter.MainView mainView;

    public MainPresenterImpl(Context context, MainPresenter.MainView mainView) {
        this.context = context;
        this.mainView = mainView;
    }

    @Override
    public void getLatestCurrencyData() {
        mainView.showLoading();
        ApiServices client = ApiManager.getRetrofitInstance().create(ApiServices.class);
        Call<CurrencyResponse> call = client.getLatestCurrency();
        call.enqueue(new Callback<CurrencyResponse>() {
            @Override
            public void onResponse(Call<CurrencyResponse> call, Response<CurrencyResponse> response) {
                if (response.isSuccessful()) {
                    // Log all rates for developer to check data
                    Log.e(TAG, "DATA:" + new Gson().toJson(response.body().getRates()));
                    mainView.showRate(response.body().getInfo(), response.body().getDescription(), response.body().getRates());
                }else {
                    Log.e(TAG, "RETROFIT ERROR");
                }
                mainView.hideLoading();
            }

            @Override
            public void onFailure(Call<CurrencyResponse> call, Throwable t) {
                mainView.hideLoading();
                // LOG ERROR WHEN GOT ERROR IN FETCHING API
                Log.e(TAG, "ERROR:" + t.getMessage());
            }
        });
    }
}
