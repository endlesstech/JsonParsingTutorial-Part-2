package com.itbankus.fetchdatausingretrofit.presenter;

import java.util.Map;

public interface MainPresenter {

    interface MainAllActions {
        void getLatestCurrencyData();
    }

    interface MainView {
        void showLoading();
        void hideLoading();
        void showRate(String info, String description, Map<String, String> rates);
    }

}
