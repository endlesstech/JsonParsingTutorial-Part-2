package com.itbankus.fetchdatausingretrofit.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.itbankus.fetchdatausingretrofit.R;
import java.util.Map;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CurrencyAdapter extends RecyclerView.Adapter<CurrencyAdapter.CurrencyViewHolder> {
    Context context;
    Map<String, String> data;
    String[] currencies = { "USD", "CAD", "GBP", "NOK", "ILS", "SEK", "DKK", "AUD", "RUB", "KWD", "EUR", "INR", "ZAR", "NPR", "CNY", "CHF",
    "PKR", "KES", "THB", "EGP", "BDT", "SAR", "LAK", "IDR", "KHR","SGD", "LKR", "NZD", "CZK", "JPY", "VND", "PHP", "KRW", "HKD", "BRL", "RSD", "MYR"};
    public CurrencyAdapter(Context context, Map<String, String> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public CurrencyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CurrencyViewHolder(LayoutInflater.from(context).inflate(R.layout.currency_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CurrencyViewHolder holder, int position) {
        holder.title.setText(currencies[position] + ":");
        holder.value.setText(data.get(currencies[position]));
    }

    @Override
    public int getItemCount() {
        return currencies.length;
    }

    public class CurrencyViewHolder extends RecyclerView.ViewHolder{
        @BindView(R.id.title)
        TextView title;

        @BindView(R.id.tv_value)
        TextView value;

        public CurrencyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
