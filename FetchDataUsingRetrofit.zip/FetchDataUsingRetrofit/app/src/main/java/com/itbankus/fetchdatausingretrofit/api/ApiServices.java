package com.itbankus.fetchdatausingretrofit.api;

import com.itbankus.fetchdatausingretrofit.model.CurrencyResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiServices {

    @GET("api/latest")
    Call<CurrencyResponse> getLatestCurrency();
}
